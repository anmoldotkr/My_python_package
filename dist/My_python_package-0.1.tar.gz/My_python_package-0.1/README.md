# My Package

A simple example package.

## Installation

```bash
pip install package_publishing